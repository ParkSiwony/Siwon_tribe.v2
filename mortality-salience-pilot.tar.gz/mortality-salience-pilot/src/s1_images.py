"""1단계 — 프롬프트로 이미지 쌍을 생성한다.

산출물: outputs/images/{MS,LT}/*.png, manifest.csv, contact_sheet.png

쌍 구조는 이 단계에서만 만들 수 있다. 나중에 되돌리려면 생성과 TRIBE 예측을
전부 다시 해야 하므로, 단일 이미지가 아니라 반드시 target/control 쌍으로 만든다.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import yaml

from .common import ROOT, checklist, load_config, manifest_path

MIN_PAIRS_PER_COND = 8


def read_prompts(folder: Path) -> dict[str, list[tuple[str, str, str]]]:
    out: dict[str, list[tuple[str, str, str]]] = {}
    for f in sorted(folder.glob("*.yaml")):
        spec = yaml.safe_load(f.read_text(encoding="utf-8"))
        out[spec["condition"]] = [(p["family"], p["target"], p["control"]) for p in spec["pairs"]]
    if not out:
        raise FileNotFoundError(f"{folder} 에 프롬프트 yaml 이 없다")
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="1단계: 이미지 쌍 생성")
    ap.add_argument("--dry-run", action="store_true", help="확산모형 없이 선화로 대체")
    ap.add_argument("--config", default=None)
    args = ap.parse_args(argv)

    cfg = load_config(args.config)
    prompts = read_prompts(ROOT / "prompts")
    out_dir = cfg["paths"]["images"]

    from mortality_tribe import pilot_images as pi

    if args.dry_run:
        manifest = pi.draw_pairs_procedural(out_dir, seeds=cfg["images"]["seeds"])
    else:
        manifest = pi.generate_pairs_diffusers(
            out_dir, model_id=cfg["images"]["model_id"], seeds=cfg["images"]["seeds"],
            size=cfg["images"]["size"], prompts=prompts)

    manifest.to_csv(manifest_path(cfg), index=False)
    sheet = pi.contact_sheet(manifest, out_dir / "contact_sheet.png")

    n_pairs = manifest.groupby("cond").pair_id.nunique()
    print("\n[쌍 수]")
    for cond, n in n_pairs.items():
        flag = "" if n >= MIN_PAIRS_PER_COND else f"   [!!] {MIN_PAIRS_PER_COND}쌍 미만"
        print(f"  {cond}: {n}쌍{flag}")
    if (n_pairs < MIN_PAIRS_PER_COND).any():
        print(f"  ※ 조건당 {MIN_PAIRS_PER_COND}쌍 미만이면 이후 부호뒤집기 검정이")
        print("    자료와 무관하게 유의해질 수 없다. 프롬프트를 더 넣을 것.")

    checklist("1단계", [
        f"접촉 시트를 열어 볼 것: {sheet}",
        "쌍마다 '의미를 나르는 디테일 하나'만 다른지 — 배경·구도·색조가 같이 바뀐 쌍은 버린다",
        "버린 뒤에도 조건당 8쌍 이상 남는지 확인하고, 모자라면 프롬프트를 추가한다",
        "버릴 쌍은 manifest.csv 에서 해당 pair_id 행을 지우고 다시 저장한다",
    ])
    print(f"manifest: {manifest_path(cfg)}  ({len(manifest)}행)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
