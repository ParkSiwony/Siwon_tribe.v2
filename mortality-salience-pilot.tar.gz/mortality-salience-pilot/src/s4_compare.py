"""4단계 — 이미지에서 온 방향과 텍스트 CAA 방향을 비교한다.

산출물: outputs/compare/cosine.csv, item_profile.csv, effect_table.csv

이 단계가 연구 질문의 두 번째 절반이다: "이미지 조향이 텍스트 조향과
어떻게 얼마나 다른가". 어느 한쪽을 고르는 단계가 아니다 — 차이 자체가 결과다.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from .common import ROOT, checklist, load_config, load_json


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="4단계: 이미지 방향 대 텍스트 방향")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--config", default=None)
    args = ap.parse_args(argv)

    cfg = load_config(args.config)
    layer = load_json(cfg["paths"]["vectors"] / "layer.json")["injection_layer"]
    u_files = sorted(cfg["paths"]["vectors"].glob("u_*.npy"))
    U = {f.stem: np.load(f) for f in u_files}
    if not U:
        raise FileNotFoundError("outputs/vectors 가 비었다 — s3_steer 를 먼저 실행할 것")

    from mortality_tribe import caa, pilot_steer as ps

    if args.dry_run:
        from .common import dry_stack
        llm, tok, _ = dry_stack(cfg)
    else:
        llm, tok = ps.load_llm(cfg["llm"]["path"])

    pairs = caa.load_pairs(ROOT / cfg["data"]["text_pairs"])
    present = set(pairs["set"].unique()) if "set" in pairs.columns else set()
    targets = [s for s in ("mort_self", "mort_struct") if s in present] or sorted(present)[:1]
    controls = [s for s in ("neg_affect", "neg_sensory", "neg_self", "arb") if s in present]
    print(f"[텍스트 세트] 표적 {targets} · 통제 {controls}")

    V, qual = caa.extract_vectors(llm, tok, pairs, layer, targets=targets, controls=controls)
    qual.to_csv(cfg["paths"]["compare"] / "text_vector_quality.csv", index=False)
    print("\n[텍스트 벡터 품질]")
    print(qual.round(3).to_string(index=False))

    rows = [dict(image=iu, text=tv, cos=cosine(U[iu], V[tv])) for iu in U for tv in V]
    cos_df = pd.DataFrame(rows).pivot(index="image", columns="text", values="cos")
    cos_df.to_csv(cfg["paths"]["compare"] / "cosine.csv")
    print("\n[코사인] 이미지 방향 x 텍스트 방향")
    print(cos_df.round(3).to_string())

    # --- 같은 항목에서 같은 방식으로 움직이는가 ---------------------------
    items = ps.load_items(ROOT / cfg["data"]["items"])
    letters = ps.letter_token_ids(tok)
    h_norm = ps.residual_norm(llm, tok, [it.scenario for it in items[:16]], layer)
    eps = max(cfg["llm"]["eps_list"])
    allv = {**U, **V}  # caa.extract_vectors 의 키는 이미 v_ 로 시작한다
    sweep = ps.steering_sweep(llm, tok, items, allv, [0.0, eps], layer, h_norm)
    sweep.to_csv(cfg["paths"]["compare"] / "sweep_both.csv", index=False)

    # 무주입 기준선은 vector="none" 으로 한 번만 기록된다. A/B 두 순서는 항목별로 먼저 평균한다.
    per_item = sweep.groupby(["vector", "eps_rel", "item"]).delta.mean()
    base = per_item.loc[("none", 0.0)]
    hi = per_item.xs(eps, level="eps_rel")
    prof = {v: (hi.loc[v] - base).rename(v) for v in allv if v in hi.index.get_level_values(0)}
    P = pd.DataFrame(prof)
    P.corr().to_csv(cfg["paths"]["compare"] / "item_profile.csv")
    print(f"\n[항목 프로파일 상관] ε = {eps}")
    print(P.corr().round(3).to_string())

    eff = sweep.groupby(["vector", "eps_rel", "axis"]).delta.mean().unstack("axis")
    eff.to_csv(cfg["paths"]["compare"] / "effect_table.csv")
    print("\n[축별 평균 효과]")
    print(eff.round(4).to_string())

    checklist("4단계", [
        "cos(u_MS, v_mort_self) 가 0 에서 떨어져 있는지 — 0 근처면 두 경로가 다른 방향이다",
        "항목 프로파일 상관: 이미지 방향과 텍스트 방향이 같은 항목을 움직이는가",
        "텍스트 안에서 cos(v_mort_self, v_neg_affect) 와 비교할 것 — 이미지가 더 갈라놓는가",
        "두 축(ingroup_norm / outgroup_exclusion)의 효과 비율이 경로별로 다른지",
    ])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
