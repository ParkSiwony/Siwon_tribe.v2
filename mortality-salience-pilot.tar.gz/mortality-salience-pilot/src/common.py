"""경로·설정·매니페스트. 네 단계가 공유하는 것은 여기 있는 것뿐이다."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]


def load_config(path: str | Path | None = None) -> dict:
    cfg = yaml.safe_load((Path(path) if path else ROOT / "config.yaml").read_text(encoding="utf-8"))
    for key, rel in cfg["paths"].items():
        p = ROOT / rel
        p.mkdir(parents=True, exist_ok=True)
        cfg["paths"][key] = p
    return cfg


def manifest_path(cfg: dict) -> Path:
    return cfg["paths"]["images"] / "manifest.csv"


def read_manifest(cfg: dict) -> pd.DataFrame:
    p = manifest_path(cfg)
    if not p.exists():
        raise FileNotFoundError(f"{p} 가 없다 — s1_images 를 먼저 실행할 것")
    return pd.read_csv(p)


def save_json(path: Path, obj: dict) -> Path:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")
    return path


def load_json(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"{path} 가 없다 — 앞 단계를 먼저 실행할 것")
    return json.loads(path.read_text(encoding="utf-8"))


def checklist(title: str, lines: list[str]) -> None:
    print("\n" + "=" * 68)
    print(f"[{title}] 다음에 눈으로 확인할 것")
    print("=" * 68)
    for i, line in enumerate(lines, 1):
        print(f"  {i}. {line}")
    print()


def dry_stack(cfg: dict):
    """DRY_RUN용 (llm, tok, tribe). s2 와 s3 가 같은 가짜 모형을 다시 만들도록
    말뭉치와 씨앗을 고정한다 — 두 단계를 따로 실행해도 같은 모형이 나온다."""
    from mortality_tribe import caa, pilot_fakes as pf, pilot_steer as ps

    items_path = ROOT / cfg["data"]["items"]
    pairs_dir = ROOT / cfg["data"]["text_pairs"]
    if not pairs_dir.exists():
        pairs_dir = pf.write_dry_pairs(cfg["paths"]["cache"] / "pairs_dry")
    items = ps.load_items(items_path if items_path.exists() else None)
    pairs = caa.load_pairs(pairs_dir).head(400)
    corpus = " ".join(
        [f"{it.scenario} {it.defensive} {it.inclusive}" for it in items[:200]]
        + (pairs.context + " " + pairs.pos + " " + pairs.neg).tolist())
    save_dir = cfg["paths"]["cache"] / "tiny_llama"
    llm, tok = pf.tiny_llama(save_dir, corpus)
    tribe = pf.FakeTribe(llm, tok, save_dir, n_vertices=cfg["tribe"]["n_vertices"])
    return llm, tok, tribe
