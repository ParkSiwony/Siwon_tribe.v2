"""2단계 — 이미지를 TRIBE 에 넣고 예측 뇌활성도를 본다.

산출물: outputs/brain/maps.npy (이미지 x 정점), lag.json, figures/*.png

이 단계의 목적은 가설 검정이 아니라 **TRIBE 가 도는지 확인하고 그림을 보는 것**이다.
각 이미지는 회색-이미지-회색 영상 한 편이 되고, 같은 길이의 전부-회색 영상이
기저로 빠진다. 반응 창은 가정하지 않고 자료에서 추정한다(estimate_peak_lag).
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .common import checklist, load_config, read_manifest, save_json


def build_videos(cfg, manifest, pi) -> dict[str, Path]:
    pres = pi.Presentation(**cfg["presentation"])
    vdir = cfg["paths"]["videos"]
    videos: dict[str, Path] = {}
    for row in manifest.itertuples():
        key = f"{row.pair_id}_{row.role}"
        videos[key] = pi.make_image_video(row.path, vdir / f"{key}.mp4", pres,
                                          size=cfg["images"]["size"])
    videos["grey"] = pi.make_image_video(None, vdir / "grey.mp4", pres,
                                         size=cfg["images"]["size"])
    return videos


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="2단계: TRIBE 예측과 뇌 지도")
    ap.add_argument("--dry-run", action="store_true", help="가짜 TRIBE 로 배선만 확인")
    ap.add_argument("--config", default=None)
    args = ap.parse_args(argv)

    cfg = load_config(args.config)
    manifest = read_manifest(cfg)
    bdir = cfg["paths"]["brain"]

    from mortality_tribe import pilot_images as pi

    videos = build_videos(cfg, manifest, pi)
    print(f"[영상] {len(videos)}편 (회색 기저 1편 포함)")

    if args.dry_run:
        from .common import dry_stack
        _, _, tribe = dry_stack(cfg)
    else:
        from tribev2 import TribeModel
        tribe = TribeModel.from_pretrained(cfg["tribe"]["checkpoint"],
                                           cache_folder=str(cfg["paths"]["cache"]))

    responses = pi.predict_timelines(tribe, videos)
    image_keys = [k for k in videos if k != "grey"]
    onset = float(cfg["presentation"]["lead"])

    lag, lag_table = pi.estimate_peak_lag(responses, "grey", onset, image_keys)
    maps = pi.image_maps(responses, "grey", onset, lag, image_keys)

    np.save(bdir / "maps.npy", maps)
    lag_table.to_csv(bdir / "lag_table.csv", index=False)
    save_json(bdir / "lag.json", {
        "peak_lag": float(lag),
        "suggested_pred_offset": float(pi.suggested_pred_offset(lag, cfg["presentation"]["show"])),
        "onset": onset,
        "image_keys": image_keys,
        "n_vertices": int(maps.shape[1]),
    })

    fig_dir = bdir / "figures"
    fig_dir.mkdir(exist_ok=True)
    map_dir = bdir / "per_image"
    map_dir.mkdir(exist_ok=True)
    for k, m in zip(image_keys, maps):
        np.save(map_dir / f"{k}.npy", m)
    try:
        from mortality_tribe.plotting import plot_maps
        made = plot_maps(map_dir, fig_dir)
        print(f"[그림] {len(made)}장 -> {fig_dir}")
    except Exception as exc:  # 표면 그리기는 선택 사항이다
        print(f"[그림] 건너뜀 ({type(exc).__name__}: {exc})")

    print(f"\n[시간축] 추정 정점 지연 {lag:.2f} s")
    checklist("2단계", [
        f"figures 의 표면 그림을 열어 볼 것 — 시각 영역이 켜져 있어야 한다",
        f"lag_table.csv 의 시간 곡선이 혈역학적으로 그럴듯한 모양인지 (상승-정점-하강)",
        "정점 지연이 0 s 근처면 시간축 변환이 안 된 것이고, 10 s 를 넘으면 창이 어긋난 것이다",
        "여기서 그림이 이상하면 3단계로 넘어가지 말 것 — 역산은 이 지도를 표적으로 삼는다",
    ])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
