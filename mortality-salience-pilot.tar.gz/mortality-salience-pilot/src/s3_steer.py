"""3단계 — 예측 뇌 지도에서 Llama 방향을 역추출하고 조향 결과를 본다.

산출물: outputs/vectors/*.npy, inversion.csv, outputs/steer/sweep.csv, summary.csv

주입층은 자유 선택이 아니다. TRIBE 가 읽는 Llama 층에서 결정된다 —
다른 층에 주입하면 역산한 방향의 의미가 성립하지 않는다.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from .common import ROOT, checklist, load_config, load_json, read_manifest, save_json


def neutral_batches(tribe, items, pb, n_passages: int = 8, per_passage: int = 12):
    """조향 대상이 아닌 평범한 문장으로 TRIBE 입력 배치를 만든다.
    역산은 '이 문장들에 u 를 더하면 피질이 어떻게 바뀌는가'를 푸는 문제다."""
    texts = [it.scenario for it in items]
    passages = {f"p{i}": " ".join(texts[i * per_passage:(i + 1) * per_passage])
                for i in range(n_passages)}
    passages = {k: v for k, v in passages.items() if v.strip()}
    events = pb.text_events(passages)
    return pb.text_batches(tribe, events), events


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="3단계: 역산 + 조향")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--skip-steer", action="store_true", help="역산까지만 하고 멈춘다")
    ap.add_argument("--config", default=None)
    args = ap.parse_args(argv)

    cfg = load_config(args.config)
    manifest = read_manifest(cfg)
    maps = np.load(cfg["paths"]["brain"] / "maps.npy")
    lag = load_json(cfg["paths"]["brain"] / "lag.json")
    keys = lag["image_keys"]

    from mortality_tribe import pilot_bridge as pb, pilot_images as pi, pilot_steer as ps

    # --- 표적 지도: 조건별 쌍 차분의 평균 ---------------------------------
    order = pd.DataFrame({"key": keys})
    order["pair_id"] = order.key.str.rsplit("_", n=1).str[0]
    order["role"] = order.key.str.rsplit("_", n=1).str[1]
    mani = manifest.set_index(["pair_id", "role"])
    targets: dict[str, np.ndarray] = {}
    for cond, grp in manifest.groupby("cond"):
        diffs = []
        for pid in grp.pair_id.unique():
            try:
                it = keys.index(f"{pid}_target")
                ic = keys.index(f"{pid}_control")
            except ValueError:
                continue
            diffs.append(maps[it] - maps[ic])
        if diffs:
            targets[cond] = np.mean(diffs, 0)
            print(f"[표적] {cond}: {len(diffs)}쌍 평균")
    if not targets:
        raise RuntimeError("쌍 차분을 만들지 못했다 — manifest 의 pair_id/role 을 확인할 것")

    # --- TRIBE 가 읽는 층 ---------------------------------------------------
    if args.dry_run:
        from .common import dry_stack
        llm, tok, tribe = dry_stack(cfg)
    else:
        from tribev2 import TribeModel
        tribe = TribeModel.from_pretrained(cfg["tribe"]["checkpoint"],
                                           cache_folder=str(cfg["paths"]["cache"]))
        llm, tok = None, None

    groups = pb.tribe_text_layer_groups(tribe)
    layer = cfg["llm"]["layer"]
    layer = pb.injection_layer(groups) if layer is None else int(layer)
    print(f"[층] TRIBE 가 읽는 hidden_states 군 {groups} -> 주입층 {layer}")

    items = ps.load_items(ROOT / cfg["data"]["items"])
    batches, events = neutral_batches(tribe, items, pb)
    half = max(1, len(batches) // 2)
    fit_b, test_b = batches[:half], batches[half:] or batches[:half]

    # --- 역산: 조건별 + 부호뒤집기 귀무 -------------------------------------
    inv_rows, vectors = [], {}
    ic = cfg["inversion"]
    for cond, tgt in targets.items():
        inv = pb.invert_brain_map(tribe._model, fit_b, tgt, rel_norm=ic["rel_norm"],
                                  n_steps=ic["steps"], verbose=False)
        r_out = pb._corr(pb.delta_for(tribe._model, test_b, inv.u, inv.feature_norm), tgt)
        sym = pb.symmetry(tribe._model, test_b, inv.u, inv.feature_norm, tgt)
        vectors[f"u_{cond}"] = inv.u
        inv_rows.append(dict(target=cond, kind="real", r_fit=inv.r, r_holdout=r_out,
                             feature_norm=inv.feature_norm, **sym))
        np.save(cfg["paths"]["vectors"] / f"u_{cond}.npy", inv.u)

    for cond, tgt in targets.items():
        pair_d = np.stack([maps[keys.index(f"{p}_target")] - maps[keys.index(f"{p}_control")]
                           for p in manifest[manifest.cond == cond].pair_id.unique()
                           if f"{p}_target" in keys and f"{p}_control" in keys])
        for i, null_tgt in enumerate(pb.sign_flip_targets(pair_d, ic["n_null"])):
            inv = pb.invert_brain_map(tribe._model, fit_b, null_tgt, rel_norm=ic["rel_norm"],
                                      n_steps=ic["steps"], verbose=False)
            r_out = pb._corr(pb.delta_for(tribe._model, test_b, inv.u, inv.feature_norm), null_tgt)
            vectors[f"u_null_{cond}{i}"] = inv.u
            inv_rows.append(dict(target=f"{cond}_null{i}", kind="null",
                                 r_fit=inv.r, r_holdout=r_out, feature_norm=inv.feature_norm))
            np.save(cfg["paths"]["vectors"] / f"u_null_{cond}{i}.npy", inv.u)

    rng = np.random.default_rng(0)
    ru = rng.normal(size=len(next(iter(vectors.values()))))
    vectors["u_rand"] = ru / np.linalg.norm(ru)
    np.save(cfg["paths"]["vectors"] / "u_rand.npy", vectors["u_rand"])

    inv_df = pd.DataFrame(inv_rows)
    inv_df.to_csv(cfg["paths"]["vectors"] / "inversion.csv", index=False)
    save_json(cfg["paths"]["vectors"] / "layer.json", {"injection_layer": layer, "groups": groups})
    print("\n[역산]")
    print(inv_df.round(3).to_string(index=False))

    if args.skip_steer:
        checklist("3단계 (역산까지)", [
            "r_fit 과 r_holdout 의 차이 — 크면 방향이 문장 집합에 과적합된 것이다",
            "실제 표적의 r_holdout 이 귀무(kind=null)보다 뚜렷이 큰지",
            "directional_over_symmetric 이 1 보다 큰지 — 작으면 조향이 아니라 일반 섭동이다",
        ])
        return 0

    # --- 조향 ----------------------------------------------------------------
    if llm is None:
        llm, tok = ps.load_llm(cfg["llm"]["path"])
    letters = ps.letter_token_ids(tok)
    h_norm = ps.residual_norm(llm, tok, [it.scenario for it in items[:16]], layer)
    sweep = ps.steering_sweep(llm, tok, items, vectors, cfg["llm"]["eps_list"], layer, h_norm)
    sweep.to_csv(cfg["paths"]["steer"] / "sweep.csv", index=False)
    summary = ps.summarize_sweep(sweep)
    summary.to_csv(cfg["paths"]["steer"] / "summary.csv", index=False)
    ps.decompose(summary).to_csv(cfg["paths"]["steer"] / "decompose.csv", index=False)
    print("\n[조향 요약]")
    print(summary.round(4).to_string(index=False))

    checklist("3단계", [
        "표적 벡터의 효과가 u_null·u_rand 의 범위를 벗어나는지 — 안 벗어나면 결과가 없는 것이다",
        "ingroup_norm 과 outgroup_exclusion 을 따로 볼 것. 합치지 말 것",
        "ε 부호를 뒤집을 때 효과도 뒤집히는지 (decompose.csv)",
        "효과가 |ε| 와 함께 단조 증가하는지 — 큰 ε 에서 꺾이면 포화 구간이다",
    ])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
