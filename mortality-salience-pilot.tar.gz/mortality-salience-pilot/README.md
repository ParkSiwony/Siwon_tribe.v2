# 현저성 → 도덕적 딜레마 판단 (파일럿)

**필멸성(MS) 또는 시간 제약(LT)이 현저해진 입력은 도덕적 딜레마에서 어떤 출력을
낳는가. 그리고 그것이 조향으로 재현되는가.**

딜레마 축은 둘이며 **합치지 않는다**: `ingroup_norm`(내집단 규범 지지),
`outgroup_exclusion`(외집단 배척).

## 워크플로우 — 이 네 단계를 고정한다

```
1  이미지 생성        prompts/*.yaml ──► outputs/images/manifest.csv
2  뇌활성도 예측      manifest ──► TRIBE v2 ──► outputs/brain/maps.npy + 표면 그림
3  역산 + 조향        maps ──► u (Llama 방향) ──► 408항목 조향 결과
4  텍스트와 비교      u  대  텍스트 CAA 벡터
```

각 단계는 **혼자 돌아가고, 산출물 하나를 남기고, 눈으로 볼 점검표를 출력한다.**
앞 단계의 그림이 이상하면 다음 단계로 넘어가지 않는다.

```bash
python -m src.s1_images --dry-run      # 선화로 배선 확인
python -m src.s2_brain   --dry-run
python -m src.s3_steer   --dry-run
python -m src.s4_compare --dry-run

python -m src.s1_images                # 실제 실행 (GPU)
python -m src.s2_brain
python -m src.s3_steer
python -m src.s4_compare
```

## 설치

배관(TRIBE 래퍼·역산·조향 훅)은 기존 저장소를 그대로 쓴다. 새로 쓰지 않는다.

```bash
git clone https://github.com/ParkSiwony/siwon_tribe.v2 ../siwon_tribe.v2
pip install -e "../siwon_tribe.v2[tribe,plot,pilot]"
pip install -r requirements.txt
huggingface-cli login     # TRIBE 는 Llama-3.2-3B 를 쓴다 (게이트됨)
```

`steering_sentences/`는 옆 폴더의 기존 저장소(`../siwon_tribe.v2/steering_sentences`)에서
바로 읽는다. 두 저장소를 같은 상위 폴더에 나란히 둘 것. 다른 위치라면 `config.yaml`의
`data.items`, `data.text_pairs` 경로를 바꾼다.

## 설계에서 고정한 것은 셋뿐이다

통제 장치는 일부러 넣지 않았다. 무엇을 통제할지는 **1·2단계 그림을 보고** 정한다.
다만 되돌리는 비용이 큰 것 셋은 처음부터 넣었다.

1. **쌍 구조.** 모든 이미지는 `target`/`control` 쌍이다. 나중에 쌍을 만들려면
   생성과 TRIBE 예측을 전부 다시 해야 한다. 쌍 없이는 3단계의 표적 지도가
   "필멸성"이 아니라 "그림을 봄"을 담는다.
2. **안정적인 ID.** `pair_id = {cond}_{family}_s{seed}`. 네 단계가 이 키로 조인한다.
3. **시간축 기록.** TRIBE 예측의 행 *t* 는 *t* + 약 5 s 의 BOLD다. 2단계가
   정점 지연을 자료에서 추정해 `lag.json`에 남긴다. 이 값 없이는 지도가 무의미하다.

## 주입층은 자유 선택이 아니다

3단계는 TRIBE 가 읽는 Llama 층에서 주입층을 **자동으로 결정한다**
(`pilot_bridge.tribe_text_layer_groups` → `injection_layer`).
다른 층에 주입하면 역산한 방향의 의미가 성립하지 않는다.
`config.yaml`의 `llm.layer: null`을 바꾸지 말 것.

## 다음에 추가할 통제 (지금은 넣지 않음)

1·2단계 그림을 본 뒤에 필요한 것만 넣는다. 후보는 다음과 같다.

- 부정 정서 이미지 조건(NEG) — 필멸성과 부정 정서의 분리를 재려면 필요
- 저수준 통제 — 밝기·대비·색조가 쌍 간에 다르지 않은지
- 텍스트 CAA 의 시간 제약 대비쌍 — 현재 없다. 1번 방법으로 LT 를 조향하려면 필요
- 직교화, Holm 보정, 사전등록 가설 — 효과가 있다는 것이 먼저 확인된 뒤에
